package View;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Button;
import java.awt.Font;
import javax.swing.JTextField;



import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import java.awt.Label;
import javax.swing.SwingConstants;
import java.awt.Dimension;
import java.awt.Dialog.ModalExclusionType;

public class TelaLogin extends JFrame {
	private Button button;
	
	public TelaLogin() {
		setSize(new Dimension(450, 300));
		getContentPane().setSize(new Dimension(450, 300));
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		getContentPane().setPreferredSize(new Dimension(450, 300));
		setPreferredSize(new Dimension(450, 300));
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(124, 62, 34, 15);
		lblNewLabel.setForeground(new Color(204, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		getContentPane().add(lblNewLabel);
		
		
		txusername = new JTextField();
		txusername.setBounds(163, 60, 158, 20);
		getContentPane().add(txusername);
		txusername.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Id");
		lblNewLabel_1.setBounds(120, 117, 38, 15);
		lblNewLabel_1.setForeground(new Color(204, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		getContentPane().add(lblNewLabel_1);
		
		txsenha = new JFormattedTextField();
		txsenha.setBounds(163, 115, 158, 20);
		getContentPane().add(txsenha);
		
		button = new Button("Entrar");
		button.setBounds(208, 175, 54, 23);
		button.setActionCommand("Entrar");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Dialog", Font.BOLD, 12));
		button.setBackground(new Color(204, 0, 0));
		getContentPane().add(button);
		
		Label label = new Label("Esqueceu a senha?");
		label.setBounds(163, 233, 110, 22);
		label.setForeground(new Color(204, 0, 0));
		getContentPane().add(label);
		
		lbnoti = new JLabel("New label");
		lbnoti.setHorizontalTextPosition(SwingConstants.CENTER);
		lbnoti.setVisible(false);
		lbnoti.setForeground(new Color(204, 0, 0));
		lbnoti.setBounds(94, 22, 274, 14);
		getContentPane().add(lbnoti);
		
		initializelisteners();
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private void initializelisteners() {
		// TODO Auto-generated method stub
	
		
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JTextField txusername;
	public JFormattedTextField txsenha;
	public JLabel lbnoti;

}
