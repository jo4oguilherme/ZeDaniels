package Control;

import View.TelaLogin;

public class Start {
	public static void main(String[] args)
	{
		
		TelaLogin tl =new TelaLogin();
		tl.setVisible(true);
		
		
	}
	

}
